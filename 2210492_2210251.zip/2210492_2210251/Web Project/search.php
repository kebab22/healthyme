<?php
// Get the search query from the form input
$searchQuery = isset($_GET['q']) ? strtolower(trim($_GET['q'])) : '';

// Define an array to map search queries to pages (using the array() syntax)
$pages = array(
    'diet' => 'dietpage.html',
    'weight' => 'weight.php',
    'nutrition' => 'nutrition.php',
    // Add more mappings here as needed
);

// Check if the query matches predefined keywords in the $pages array
if (array_key_exists($searchQuery, $pages)) {
    // Redirect to the correct page if a match is found
    header('Location: ' . $pages[$searchQuery]);
    exit();
}

// If the query is not in the predefined list, proceed to call the SOAP service
try {
    // Initialize the SOAP client with the provided WSDL URL
    $client = new SoapClient("https://www.crcind.com/csp/samples/SOAP.Demo.cls?wsdl");

    // Example: Query the SOAP service using the search query
    $params = array('name' => $searchQuery);  // Assuming you're querying by name
    $result = $client->QueryByName($params);

    // Process the SOAP result
    if (isset($result->QueryByNameResult->Person)) {
        // If a person is found, redirect to a relevant page (for example)
        header('Location: person.php?name=' . urlencode($searchQuery));
        exit();
    } else {
        // No results found, show a "no results" message or redirect to a search page
        echo 'No results found for "' . htmlspecialchars($searchQuery) . '"';
    }
} catch (SoapFault $fault) {
    // Handle SOAP errors
    echo 'Error: ' . $fault->faultstring;
}
?>