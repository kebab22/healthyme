## DGT 2034Y - Internet Technologies and Web Services

-Project by :
    -2210492- Haïfa Maudarbocus
    -2210251- Jahnavi Sewnundun

## Table of contents
- [Intro](#Intro)
- [Creating the database](#creating-the-database)
- [Filling the database](#filling-database)
- [Accessing the Website](#Accessing-the-Website)
- [Admin](#Admin)

### Intro

This is our secind year project for sem1 of DGT 2034Y - Internet Technologies and Web Services at the University of Mauritius. 'HealthyMe' is the name of our wellness website. HealthyMe has several articles of diets, wellness, and weightloss. Aditionally, users can buy our merch through our shop page.

## Creating the database 

We have used MySQL to create the database and support the project.
We recommend using MySQL to avoid any code incompatibility issues 
when continuing further.

1. To access MySQL, you can use phpMyAdmin from your webserver.
2. Create a new database named 'healthyMe' with the following tables:
    > user_account
    > stock_item

## Filling database
1. Navigate to the Views folder then Admin and run the create.php file
2. You should see something like this:
    > "Tables created successful"

3. Fill the "user_account" table with the following values:
user_id username  password  first_name  last_name   is_admin
6	    haifa	  4567	    haifa	    maudarbocus	   1
5	    jah	      1234	    jahnavi	    sewnundun	   0
7	    mark	  1256	    mark	    john	       0
8	    john	  1234	    john	    tom	           0


4. The "user_account" table will be filled as you will register/ create users on the website

## Accessing the Website
Access the website via the home page 'index.html'
You can find it using the link below:
http://127.0.0.1/Web%20Project/

## Admin
To access our admin page on: 
http://127.0.0.1/Web%20Project/Admin.php
You will need the following credentials:

Username: haifa
Password: 4567

We used xml on the "stock_item" database where data is stored in crud.xml file. 
We used xml for the card page and the data is stored in file cart.xml in the User folder found in Views.

------------------------------------------------------------------------------------
The website should now be functionning. Have fun browsing through it.
Thank you.