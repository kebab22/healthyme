<?php
ini_set('display_errors', 1);
ini_set('display_startup_errors', 1);
error_reporting(E_ALL);

// Define a class that will handle SOAP requests
class ProductRecommendationService {
    // Function to recommend products based on user preference
    public function recommendProduct($preference) {
        // Simulating product recommendations
        $products = [
            'fitness' => ['Dumbell', 'Band'],
            'merch' => ['Sweater', 'Short', 'T-shirt'],
            'wellness' => ['Yoga Mat'],
            'energy' => ['Energy Bars']
        ];

        // Return a product recommendation for the given preference
        if (isset($products[$preference])) {
            $responseData = $products[$preference];
        } else {
            $responseData = [];
        }

        // Return an empty response in XML format if no products found
        if (empty($responseData)) {
            return "<products></products>";
        }

        // Convert response to XML format
        $xmlResponse = new SimpleXMLElement('<products/>');
        foreach ($responseData as $product) {
            $xmlProduct = $xmlResponse->addChild('product', $product);
        }

        // Set the content type to XML
        header('Content-Type: text/xml');
        return $xmlResponse->asXML();
    }
}

// Initialize the SOAP server
$server = new SoapServer(null, ['uri' => 'http://127.0.0.1/2210492_2210251/Web%20Project/soap_service/soap_server.php']);
$server->setClass('ProductRecommendationService');
$server->handle();
?>
