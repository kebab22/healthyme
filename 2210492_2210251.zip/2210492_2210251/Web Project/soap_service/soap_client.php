<?php
try {
    // Create a new SOAP client
    $client = new SoapClient(null, [
        'location' => 'http://127.0.0.1/2210492_2210251/Web%20Project/soap_service/soap_server.php',
        'uri' => 'http://127.0.0.1/2210492_2210251/Web%20Project/soap_service/soap_server.php'
    ]);

    // Define the preference for which you want a recommendation
    $preference = 'fitness';

    // Call the recommendProduct function on the SOAP server
    $response = $client->recommendProduct($preference);

    // Output the result
    echo '<pre>';
    print_r($response); // Display the response
    echo '</pre>';
} catch (SoapFault $e) {
    echo "Error: " . $e->getMessage();
}
?>
