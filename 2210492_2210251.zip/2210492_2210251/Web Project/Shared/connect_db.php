<?php
        //Open a connection
    $servername = "localhost";
    $username = "root";
    $password = "";
    $db = "HealthyMe";

        //create connection
    $conn = mysqli_connect($servername,$username,$password,$db);

        //check connection
    if(!$conn){
        die("Connection failed: ".mysqli_connect_error());
    }

    //echo "Connect Successfully"."<br/>";
?>