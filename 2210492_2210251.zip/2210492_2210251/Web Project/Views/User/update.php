<?php
    session_start();

    include ('connect_db.php');
    
    if (isset($_POST['uname_txt']) && (isset($_POST['new_pass_txt']))){
        $username = $_POST['uname_txt'];
        $new_password = $_POST['new_pass_txt'];

            $sql = "UPDATE user_account SET password = '$new_password' WHERE username = '$username'";
            $result = mysqli_query($conn,$sql);

            if ($result){
                echo "<script type = 'text/javascript'>alert('Your password has been successfully changed');</script>";
                header('Location: LoginPage.html');

            }else{
                echo "<script type = 'text/javascript'>alert('Username and Password does not exist');</script>";
                header('Location: LoginPage.html'); 
            }
    }

    mysqli_close($conn);
?>