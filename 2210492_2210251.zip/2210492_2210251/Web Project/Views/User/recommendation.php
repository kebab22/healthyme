<?php
ini_set('display_errors', 1);
ini_set('display_startup_errors', 1);
error_reporting(E_ALL);

if ($_SERVER["REQUEST_METHOD"] == "POST") {
    // Get the user preference from the form
    $preference = isset($_POST['preference']) ? $_POST['preference'] : '';

    try {
        // Initialize the SOAP client
        $client = new SoapClient(null, [
            'location' => 'http://127.0.0.1/2210492_2210251/Web%20Project/soap_service/soap_server.php',
            'uri' => 'http://localhost/2210492_2210251/Web%20Project/soap_service/'
        ]);
        
        
        // Call the recommendProduct method on the SOAP server
        $response = $client->recommendProduct($preference);

        // Log response for debugging (optional)
        file_put_contents('soap_log.txt', print_r($response, true), FILE_APPEND);
        
    } catch (SoapFault $e) {
        // Handle errors
        echo "Errorrrrrrrrrrrrrrrrrrrrrrrrrrrrr: " . $e->getMessage();

            echo "SOAP Fault: (faultcode: {$e->faultcode}, faultstring: {$e->faultstring})";
        
        exit;
    }
} else {
    echo "Invalid request method!";
    exit;
}
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Product Recommendations</title>
    <style>
        
        .card {
            width: 150px;
            padding: 10px;
            border: 1px solid #ccc;
            box-shadow: 0px 0px 10px rgba(0, 0, 0, 0.1);
            margin: 10px;
            display: inline-block;
            vertical-align: top;
            text-align: center;
            background-color: #f9f9f9;
            border-radius: 5px;
        }
        .card .imgbox img {
            width: 100px;
            height: auto;
            object-fit: cover;
        }
        .card h2 {
            font-size: 16px;
            margin: 10px 0 5px;
        }
        .card p {
            font-size: 14px;
            margin: 5px 0;
        }
        .card button {
            padding: 5px 10px;
            font-size: 12px;
            border: none;
            background-color: #4CAF50;
            color: white;
            cursor: pointer;
            border-radius: 3px;
        }
        .card button:hover {
            background-color: #45a049;
        }
        .back-button {
            margin: 20px;
            padding: 10px 20px;
            font-size: 16px;
            border: none;
            background-color: #007BFF;
            color: white;
            cursor: pointer;
            border-radius: 5px;
        }
        .back-button:hover {
            background-color: #0056b3;
        }
    </style>
</head>
<body>
    <header>
        <h1>My Website</h1>
        <nav>
            <a href="index.html">Home</a>
            <a href="shop.html">Shop</a>
            <a href="about.html">About</a>
            <a href="contact.html">Contact</a>
        </nav>
    </header>
    
    <button class="back-button" onclick="window.history.back();">Back</button>
    
    <div id="product-recommendations">
        <?php
        // Display the recommendations
        if (isset($response) && is_array($response)) {
            foreach ($response as $product) {
                $name = htmlspecialchars($product['name']);
                $image = htmlspecialchars($product['image']);
                $size = htmlspecialchars($product['size']);
                $price = htmlspecialchars($product['price']);
                $color = htmlspecialchars($product['color']);

                echo '
                <div class="card">
                    <div class="imgbox">
                        <img src="' . $image . '" alt="' . $name . '">
                        <h2>' . $name . '</h2>
                        <p>' . $size . '</p>
                        <button class="add-to-cart-btn" data-name="' . $name . '" 
                                data-size="' . $size . '" 
                                data-price="' . $price . '" 
                                data-color="' . $color . '" 
                                data-image="' . $image . '" 
                                onclick="addItemToCart(this)">Add to Cart</button>
                    </div>
                </div>';
            }
        } else {
            echo '<p>No products available at the moment.</p>';
        }
        ?>
    </div>
    
    <script>
        function addItemToCart(button) {
            const productName = button.getAttribute("data-name");
            const productSize = button.getAttribute("data-size");
            const productPrice = button.getAttribute("data-price");
            const productColor = button.getAttribute("data-color");
            const productImage = button.getAttribute("data-image");

            const product = {
                name: productName,
                size: productSize,
                price: productPrice,
                color: productColor,
                image: productImage
            };

            let cart = localStorage.getItem("cart");

            if (cart) {
                try {
                    cart = JSON.parse(cart);
                    if (!Array.isArray(cart)) {
                        cart = [];
                    }
                } catch (e) {
                    cart = [];
                }
            } else {
                cart = [];
            }

            cart.push(product);
            localStorage.setItem("cart", JSON.stringify(cart));

            alert(productName + " has been added to your cart.");
        }
    </script>
</body>
</html>
