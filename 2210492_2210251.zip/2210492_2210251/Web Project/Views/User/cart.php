<?php
// Function to remove an item from the XML file
function removeItem($itemId) {
    // Load the XML file
    $xml = simplexml_load_file('cart.xml');

    // Find the product with the given id
    foreach ($xml->product as $product) {
        if ($product['id'] == $itemId) {
            // Remove the product from the XML
            unset($product[0]);
            break; // Exit the loop once the product is removed
        }
    }

    // Save the modified XML back to the file
    $xml->asXML('cart.xml');
}

// Check if itemId is provided through GET request
if (isset($_GET['itemId'])) {
    // Call removeItem function with the provided itemId
    removeItem($_GET['itemId']);
}
?>