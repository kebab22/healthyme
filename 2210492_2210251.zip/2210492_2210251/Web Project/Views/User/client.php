<?php
if (isset($_POST['submit'])) {
    $food = $_POST['food'];
    $calories_per_serving = (float) $_POST['calories'];
    $servings = (float) $_POST['servings'];

    try {
        // WSDL URL for the SOAP service
        $wsdl = "http://www.dneonline.com/calculator.asmx?wsdl"; // Replace with the actual WSDL URL

        // Initialize SoapClient with the WSDL URL
        $client = new SoapClient($wsdl, array('trace' => 1));

        // Prepare the parameters to pass to the web service
        $params = array(
            'food' => $food,
            'caloriesPerServing' => $calories_per_serving,
            'servings' => $servings
        );

        // Call the calculateCalories method from the SOAP service
        $response = $client->__soapCall('calculateCalories', array($params));

        // Assuming the response contains a field named 'totalCalories'
        $total_calories = $response->Add;

        echo "<h3>Results:</h3>";
        echo "<p>Food: <strong>{$food}</strong></p>";
        echo "<p>Total Calories: <strong>{$total_calories}</strong> kcal</p>";
    } catch (SoapFault $fault) {
        // Handle any errors from the SOAP request
        echo "<p style='color: red;'>Error: {$fault->faultstring}</p>";
    }
} else {
    echo "<p>No data submitted.</p>";
}
?>
