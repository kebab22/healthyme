<?php

    // Retrieve the XML content sent by the client
    $xmlContent = file_get_contents("php://input");

    // Specify the path to the XML file
    $xmlFilePath = "cart.xml";

    // Write the XML content to the file
    $file = fopen($xmlFilePath, "w") or die("Unable to open file!");
    fwrite($file, $xmlContent);
    fclose($file);

   
    
  
?>