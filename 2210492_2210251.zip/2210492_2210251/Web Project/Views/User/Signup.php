<!DOCTYPE html>
<html lang="en">
<head>
	<title> SIGN UP </title>
	<link rel="stylesheet" href="stylesignup.css">
	<link rel="icon" href="../photos/final-logo.jfif">
</head>
<body>



<div class="border">
	<nav class="nav">
			<img class="logo" src="../photos/final-logo.jfif">
	<ul>
					<li><a class="active" href="index.html">Home</a></li>
					<li><button onmouseover="toggleMenu()" class="dropbtn">Newsletter</button></li>
<div class="sub-menu-wrap" id="subMenu">
 
	<div class="sub-menu">
		<div class="user-info">
   
	
            <h1> Our Newsletter</h1>
			<p> Subscribe to become a member and obtain the latest updates.</p>
			
	
			    <form name="txtname" id="txtname" type="text" action="process.php" method="POST">
			    <label for="txtname"></label>
			    <input type="First Name" id="txtname" name="txtname" placeholder="First Name"/><br><br>
			    <label for="txtname"></label>
			    <input type="Last name" id="txtname" name="txtname" placeholder="Last Name"/><br><br>
			    <label for="txtname"></label>
			    <input type="email" id="txtname" name="txtname" placeholder="Email"/><br><br>
			    <label for="txtname"></label>
			    <input type="Password" id="txtname" name="txtname" placeholder="Password"/><br><br>
			    <label for="txtname"></label>
			    <input type="Password" id="txtname" name="txtname" placeholder="Confirm Password"/><br><br>
			    <label for="checkbox"><a href="Terms of use & Privacy policy" target="_blank">I accept the Terms of use & Privacy policy </a></label>
			    <input type="checkbox" class="onoffswitch checkbox" id="inline" checked="true"><br><br>
			    <a href="HealthyMe"><input type="button" class="button2" value="Subscribe"></a>
				
	
	    </div>
	</div>
</div>
					
					
					<li><a href="Login page.html" class="active2">Login</a></li>
				</ul>
	</nav>
</div>
<div class="form">

				<form name="frm_login" action="process.php" method="POST" class="form">
                <h4> Don't have an account? Just sign up! </h4>
				<p><font color="grey"> It will only take a few minutes.</font></p>

				<br>
				<label form="text_name"> </label>
				<input type="text" id="txt_name" name="txt_name" placeholder="Create a username">

				<br>

				<p><label form="txt_name"></label>
				<input type="password" id="txt_name" name="txt_name" placeholder="Create a password" ></p>

				<p><label form="txt_name">  </label>
					<input type="password" id="txt_name" name="txt_name" placeholder="Confirm password"></p>
				<a href="index.html"><center><p><input type="button" class="button" value="Sign up"/></button></p></center></a>
</div>
</form>
</body>
</html>
<script>
	let subMenu = document.getElementById("subMenu");
	function toggleMenu(){
		subMenu.classList.toggle("open-menu");
	}
</script>