<!--process for login page-->
<?php
include('connect_db.php');


$username = $_POST['uname_txt'];
$password = $_POST['pass_txt'];

//check if user already exists
$val = "SELECT username FROM user_account WHERE username = '$username'";


$query = mysqli_query($conn, $val);
//check if num rows greater than 0 (if exists)
if (mysqli_num_rows($query) > 0) {
    echo "<script type = 'text/javascript'>
    alert('Welcome.');
    window.location.href= 'shop.html';
    </script>";
   // header('Location: shop.html');
} else {
    echo "<script type = 'text/javascript'>
    alert('Username does not Exist! Sign Up to Continue.');
    window.location.href= 'signup.html';
    </script>";
}

mysqli_close($conn);

?>