<!--process for sign up page-->
<?php
include('connect_db.php');

//$user_id = $_POST['user_id'];
$username = $_POST['uname_txt'];
$password = $_POST['pass_txt'];
$first_name = $_POST['fname_txt'];
$last_name = $_POST['lname_txt'];
$is_admin = $_POST['useradmin'];

//check if user already exists
$val = "SELECT username FROM user_account WHERE first_name = '$first_name' AND last_name = '$last_name'";

$query = mysqli_query($conn, $val);
//check if num rows greater than 0 (if exists)
if (mysqli_num_rows($query) > 0) {
	echo "<script type = 'text/javascript'>
	alert('User Already Exists. Please login');
	window.location.href = 'LoginPage.html';
	</script>";
} else {

	//convert checkbox into bool
	$is_admin = isset($_POST['useradmin']) && $_POST['useradmin'] === 'on';

	//convert bool into int
	$is_admin = intval($is_admin);

	$sql = "INSERT INTO user_account(username,password,first_name,last_name,is_admin) VALUES (?,?,?,?,?)";


	//check if the prepared result was executed successfully then close the result and redirect to shop 
	$result = mysqli_prepare($conn, $sql);
	if ($result) {
		mysqli_stmt_bind_param($result, "ssssi", $username, $password, $first_name, $last_name, $is_admin);
		if (mysqli_stmt_execute($result)) {
			echo "<script type= 'text/javascript'>
			alert('Welcome.$first_name');
			window.location.href = 'shop.html';
			</script>";
		} else {
			echo "<script>alert('Login failed.');</script>";
		}
	} else {

		echo "<script>alert('Connection failed.');</script>";
	}
}
/*
				$stmt = $conn -> prepare("INSERT INTO user_account(username,password,first_name,last_name,is_admin) VALUES (?,?,?,?,?)");

				//$stmt = $conn -> prepare("INSERT INTO user_account(username,password,first_name,last_name,is_admin) VALUES ('$username','$password','$first_name','$last_name',$is_admin )");

				$stmt -> bind_param("ssssi",$username,$password,$first_name,$last_name,$is_admin);
				$stmt -> execute();
				
				
*/

mysqli_close($conn);

?>