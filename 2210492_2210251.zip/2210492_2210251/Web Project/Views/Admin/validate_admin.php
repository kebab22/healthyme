<?php
    include ('../User/connect_db.php');

        $username = $_POST['uname_txt'];
        $password = $_POST['pass_txt'];

        $sql = "SELECT is_admin FROM user_account WHERE username = ? AND password = ?";
		$result = mysqli_prepare($conn,$sql);

        //check if the prepared result was executed successfully then close the result and redirect to admin page
        if($result){
            mysqli_stmt_bind_param($result,"ss",$username,$password);
            mysqli_stmt_execute($result);
            mysqli_stmt_bind_result($result,$is_admin);
            mysqli_stmt_fetch($result);

            mysqli_stmt_close($result);

                if($is_admin){
                    session_start();
                    $_SESSION['username'] = $username;
                    header('Location: admin_details.html');

                }
                else{
                    echo '<script> alert ("Access Denied");</script>';

                }
        }else{
                echo '<script> alert ("An Error Occured");</script>';

        }
    mysqli_close($conn);
?>