<?php
class api
{
    private $db;

    // Constructor to establish the database connection
    function __construct() {
        // Read the configuration file
        $conf = json_decode(file_get_contents('configuration.json'), TRUE);
        
        // Establish the database connection using mysqli
        $this->db = new mysqli($conf["host"], $conf["user"], $conf["password"], $conf["database"]);
        
        // Check for a connection error
        if ($this->db->connect_error) {
            die("Connection failed: " . $this->db->connect_error);
        }
    }

    // Destructor to close the database connection
    function __destruct() {
        $this->db->close();
    }

    // Method to retrieve user data
    function get($params) {
        // Base query
        $query = 'SELECT u.user_id AS id, u.username AS username, u.password AS password, 
                         u.first_name AS first_name, u.last_name AS last_name, u.is_admin AS is_admin 
                  FROM user_account AS u';
        
        // If an 'id' parameter is passed, append the WHERE clause
        if (isset($params['id']) && $params['id'] != "") {
            $query .= ' WHERE u.user_id = ' . $this->db->real_escape_string($params['id']);
        }
        
        // Execute the query
        $result = $this->db->query($query);
        
        // Initialize an empty list
        $list = array();
        
        // Fetch and store the results in an array
        if ($result) {
            while ($row = $result->fetch_assoc()) {
                $list[] = $row;
            }
        }
        
        // Return the list of users
        return $list;
    }

    // Method to create a new user
    function create($params) {
        // Prepare the SQL query to insert user data using a prepared statement
        $stmt = $this->db->prepare("INSERT INTO user_account (username, password, first_name, last_name, is_admin) 
                                    VALUES (?, ?, ?, ?, ?)");

        // Bind the parameters to the query
        $stmt->bind_param("ssssi", 
                          $params['username'], 
                          $params['password'], 
                          $params['first_name'], 
                          $params['last_name'], 
                          $params['is_admin']);
        
        // Execute the query
        if (!$stmt->execute()) {
            die("Error creating user: " . $stmt->error);
        }

        // Close the statement
        $stmt->close();
    }

    // Method to update an existing user
    function update($params) {
        // Prepare the SQL query to update user data
        $stmt = $this->db->prepare("UPDATE user_account 
                                    SET username = ?, password = ?, first_name = ?, last_name = ?, is_admin = ? 
                                    WHERE user_id = ?");

        // Bind the parameters to the query
        $stmt->bind_param("ssssii", 
                          $params['username'], 
                          $params['password'], 
                          $params['first_name'], 
                          $params['last_name'], 
                          $params['is_admin'], 
                          $params['id']);
        
        // Execute the query
        if (!$stmt->execute()) {
            die("Error updating user: " . $stmt->error);
        }

        // Close the statement
        $stmt->close();
    }

    // Method to delete a user by id
    function delete($params) {
        // Prepare the SQL query to delete a user by id
        $stmt = $this->db->prepare("DELETE FROM user_account WHERE user_id = ?");

        // Bind the parameters to the query
        $stmt->bind_param("i", $params['id']);
        
        // Execute the query
        if (!$stmt->execute()) {
            die("Error deleting user: " . $stmt->error);
        }

        // Close the statement
        $stmt->close();
    }
}
?>