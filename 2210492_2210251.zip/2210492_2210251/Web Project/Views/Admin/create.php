<?php 
    include ('connect_db.php');

            //create table user_account
        //    $sql = "CREATE TABLE `user_account` (
        //     `user_id` varchar(25) NOT NULL,
        //     `username` varchar(25) NOT NULL,
        //     `password` varchar(25) NOT NULL,
        //     `first_name` varchar(25) NOT NULL,
        //     `last_name` varchar(25) NOT NULL,
        //     `is_admin`  BOOLEAN NOT NULL,
        //     PRIMARY KEY (user_id)
        //       )";

          //create table customer
        //   $sql = "CREATE TABLE `customer` (
        //     `user_id` varchar(25) NOT NULL,
        //     `customer_id` varchar(25) NOT NULL,
        //     `first_name` varchar(25) NOT NULL,
        //     `last_name` varchar(25) NOT NULL,
        //    `city` varchar(20) NOT NULL,
        //     `street` varchar(20) NOT NULL,
        //     `postcode` varchar(10) NOT NULL,
        //     PRIMARY KEY (customer_id),
        //     FOREIGN KEY (user_id) REFERENCES user_account (user_id) ON DELETE NO ACTION
        //                                                             ON UPDATE CASCADE
        //                               )";

            //create table stock_item
        //  $sql = "CREATE TABLE `Stock_item`(
        //      `item_id` varchar(25) NOT NULL,
        //      `product_name` VARCHAR(10) NOT NULL,
        //      `in_stock` SMALLINT NOT NULL,
        //      `size` VARCHAR(5) NOT NULL,
        //      `color` VARCHAR(10) NOT NULL,
        //      `price` SMALLINT NOT NULL,
        //      PRIMARY KEY (item_id)
        //  )";

            //create table order_item
        //  $sql = "CREATE TABLE `order_item` (
        //      `order_id` varchar(25) NOT NULL,
        //      `customer_id` varchar(25) NOT NULL,
        //      `product_name` varchar(10) NOT NULL,
        //      `quantity` SMALLINT NOT NULL,
        //      `total_price` SMALLINT NOT NULL,
        //      `order_date` DATE NOT NULL,
        //      PRIMARY KEY (order_id),
        //      FOREIGN KEY (customer_id) REFERENCES customer
        //                                  ON DELETE NO ACTION
        //                                  ON UPDATE CASCADE
            
        //         )";

            //create table payment
        //  $sql = "CREATE TABLE `payment` (
        //      `payment_id` varchar(25) NOT NULL,
        //      customer_id varchar(25) NOT NULL,
        //      `amount` smallint,
        //      `payment_date` date ,
        //      PRIMARY KEY (payment_id),
        //      FOREIGN KEY (customer_id) REFERENCES customer
        //                              ON DELETE NO ACTION
        //                              ON UPDATE CASCADE
        //  )";
        
            //create table depends_on
        //  $sql = "CREATE TABLE `depends_on` (
        //     `item_id` varchar(25) NOT NULL,
        //     `order_id` varchar(25) NOT NULL,
        //      PRIMARY KEY (item_id,order_id),
        //      FOREIGN KEY (item_id) REFERENCES stock_item
        //                                  ON DELETE NO ACTION
        //                                  ON UPDATE CASCADE,
        //      FOREIGN KEY (order_id) REFERENCES order_item
        //                                  ON DELETE NO ACTION
        //                                  ON UPDATE CASCADE
        //  )";

            //create table customer_phone
            //  $sql = "CREATE TABLE `customer_phone` (
            //      `customer_id` varchar(25) NOT NULL,
            //      `customer_phone` varchar(20) NOT NULL,
            //      PRIMARY KEY (customer_id, customer_phone),
            //      FOREIGN KEY (customer_id) REFERENCES customer
            //                                  ON DELETE NO ACTION
            //                                  ON UPDATE CASCADE
             //)";
    
        
            if(mysqli_query($conn, $sql)){
                echo "Table created successfully";
            }
            else{
                echo "Error creating table"."<br/>";
                mysqli_error($conn);
        }
        mysqli_close($conn);
?>