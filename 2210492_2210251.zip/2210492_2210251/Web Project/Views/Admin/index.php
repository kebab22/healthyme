<?php
require_once 'api.php'; // Include the API class

$api = new api(); // Create an instance of the API class
$message = array();
$data = array();

// Check if the form has been submitted
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    switch ($_POST["action"]) {
        case 'get':
            $params = array();
            // Check if an ID is provided
            if (isset($_POST["id"])) {
                $params['id'] = $_POST["id"];
            } else {
                $params['id'] = '';
            }

            // Call the 'get' method and retrieve data
            if (is_array($data = $api->get($params))) {
                $message["code"] = "0"; // Success
                $message["data"] = $data;
            } else {
                $message["code"] = "1"; // Error
                $message["message"] = "Error on get method";
            }
            break;

        case 'create':
            // Gather the data from the form
            $userData = array(
                'username' => isset($_POST['username']) ? $_POST['username'] : '',
                'password' => isset($_POST['password']) ? $_POST['password'] : '',
                'first_name' => isset($_POST['first_name']) ? $_POST['first_name'] : '',
                'last_name' => isset($_POST['last_name']) ? $_POST['last_name'] : '',
                'is_admin' => isset($_POST['is_admin']) ? 1 : 0
            );

            // Call the 'create' method to create a new user
            if ($api->create($userData)) {
                $message["code"] = "0"; // Success
                $message["message"] = "User created successfully.";
            } else {
                $message["code"] = "1"; // Error
                $message["message"] = "Error creating user.";
            }
            break;

        case 'update':
            // Update an existing user
            $userUpdate = array(
                'id' => $_POST["id"],
                'username' => $_POST["username"],
                'password' => $_POST["password"],
                'first_name' => $_POST["first_name"],
                'last_name' => $_POST["last_name"],
                'is_admin' => $_POST["is_admin"]
            );
            $api->update($userUpdate);
            $data = $api->get(array()); // Refresh the data
            break;

            if ($api->update($userUpdate)) {
                $message["code"] = "0"; // Success
                $message["message"] = "User created successfully.";
            } else {
                $message["code"] = "1"; // Error
                $message["message"] = "Error creating user.";
            }
            break;

        case 'delete':
            // Delete a user
            $userDelete = array('id' => $_POST["id"]);
            $api->delete($userDelete);
            $data = $api->get(array()); // Refresh the data
            break;

            if ($api->delete($userDelete)) {
                $message["code"] = "0"; // Success
                $message["message"] = "User created successfully.";
            } else {
                $message["code"] = "1"; // Error
                $message["message"] = "Error creating user.";
            }
            break;




        default:
            $message["code"] = "1"; // Error for unknown action
            $message["message"] = "Unknown method: " . $_POST["action"];
            break;
    }
}

// Output as JSON for debugging (you can remove this after testing)
// header('Content-type: application/json; charset=utf-8');
// echo json_encode($message, JSON_PRETTY_PRINT | JSON_UNESCAPED_UNICODE | JSON_UNESCAPED_SLASHES);

?>

<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta http-equiv="Content-Type" content="text/html; charset=iso-8859-1">
    <title>User Management</title>
    <link rel="stylesheet" type="text/css" href="../../Assets/CSS/stylelog.css">
    <link rel="icon" href="../../Assets/Images/final-logo.jfif">
    <style>
        body {
            font-family: Arial, sans-serif;
            margin: 20px;
        }

        table {
            width: 100%;
            border-collapse: collapse;
            margin-top: 20px;
        }

        table,
        th,
        td {
            border: 1px solid #ddd;
            padding: 10px;
        }

        th {
            background-color: #f2f2f2;
        }

        input,
        select {
            padding: 5px;
            width: 100%;
        }

        form {
            margin-bottom: 20px;
        }

        .submit-btn {
            padding: 10px 20px;
            background-color: #4CAF50;
            color: white;
            border: none;
            cursor: pointer;
        }

        .delete-btn,
        .edit-btn {
            padding: 5px 10px;
            background-color: red;
            color: white;
            border: none;
            cursor: pointer;
        }

        .edit-btn {
            background-color: blue;
        }

        /* .submit-btn { background-color: blue; } */
        #updateForm {
            display: none;
        }

        /* Hide update form initially */
    </style>
</head>

<body>
    <div class="border">
        <nav class="nav">
            <img class="logo" src="../../Assets/Images/final-logo.jfif">
            <ul>
                <li><a class="active" href="../../index.html">Home</a></li>

                <!--logout button redirecting back to index-->
                <li><a href="index.html" class="active2">Logout</a></li>
            </ul>
        </nav>
    </div>
    <h2>User Management</h2>

    <!-- Form to submit GET request -->
    <h3>Get User Data</h3>
    <form name="form" method="post" action="index.php">
        <input type="hidden" name="action" value="get">
        <table>
            <tr>
                <td>ID</td>
                <td><input name="id" type="text" size="50" maxlength="50"></td>

            </tr>
            <tr>
                <td colspan="3"><input type="submit" name="boton" value="Get User"></td>
            </tr>
        </table>
    </form>

    <!-- Form to submit CREATE request -->
    <h3>Create New User</h3>
    <form name="createForm" method="post" action="index.php">
        <input type="hidden" name="action" value="create">
        <table>
            <tr>
                <td>Username</td>
                <td><input name="username" type="text" size="50" maxlength="50" required></td>
            </tr>
            <tr>
                <td>Password</td>
                <td><input name="password" type="password" size="50" maxlength="50" required></td>
            </tr>
            <tr>
                <td>First Name</td>
                <td><input name="first_name" type="text" size="50" maxlength="50" required></td>
            </tr>
            <tr>
                <td>Last Name</td>
                <td><input name="last_name" type="text" size="50" maxlength="50" required></td>
            </tr>
            <tr>
                <td>Is Admin</td>
                <td><input name="is_admin" type="checkbox" value="1"></td>
            </tr>
            <tr>
                <td colspan="3"><input type="submit" name="boton" value="Create User"></td>

            </tr>
        </table>
    </form>

    <!-- Update Form which is initially hidden -->
    <div id="updateForm">
        <h3>Update User</h3>
        <form method="post" action="index.php">
            <input type="hidden" name="action" value="update">
            <input type="hidden" name="id" id="updateId">

            <label>Username:</label>
            <input type="text" name="username" id="updateUsername" required><br>

            <label>Password:</label>
            <input type="text" name="password" id="updatePassword" required><br>

            <label>First Name:</label>
            <input type="text" name="first_name" id="updateFirstName" required><br>

            <label>Last Name:</label>
            <input type="text" name="last_name" id="updateLastName" required><br>

            <label>Is Admin:</label>
            <select name="is_admin" id="updateIsAdmin" required>
                <option value="0">No</option>
                <option value="1">Yes</option>
            </select><br><br>

            <input type="submit" value="Update User" class="submit-btn">
        </form>
    </div>


    <!-- Display the retrieved user data or error message -->
    <?php if (!empty($data)) { ?>
        <h3>Retrieved User Data</h3>
        <table border="1" cellpadding="5" cellspacing="0">
            <thead>
                <tr>
                    <th>ID</th>
                    <th>Username</th>
                    <th>Password</th>
                    <th>First Name</th>
                    <th>Last Name</th>
                    <th>Is Admin</th>
                </tr>
            </thead>
            <tbody>
                <?php foreach ($data as $user) { ?>
                    <tr>
                        <td><?php echo htmlspecialchars($user['id']); ?></td>
                        <td><?php echo htmlspecialchars($user['username']); ?></td>
                        <td><?php echo htmlspecialchars($user['password']); ?></td>
                        <td><?php echo htmlspecialchars($user['first_name']); ?></td>
                        <td><?php echo htmlspecialchars($user['last_name']); ?></td>
                        <td><?php echo htmlspecialchars($user['is_admin']); ?></td>


                    </tr>
                <?php } ?>
                <tr>
                    <td><button class="edit-btn"
                            onclick="showUpdateForm(<?php echo $user['id']; ?>, '<?php echo $user['username']; ?>', '<?php echo $user['password']; ?>', '<?php echo $user['first_name']; ?>', '<?php echo $user['last_name']; ?>', <?php echo $user['is_admin']; ?>)">Edit</button>
                    </td>

                    <td>
                        <form method="post" action="index.php">
                            <input type="hidden" name="action" value="delete">
                            <input type="hidden" name="id" value="<?php echo $user['id']; ?>">
                            <input type="submit" value="Delete User" class="submit-btn">
                    </td>
                </tr>
            </tbody>
        </table>
    <?php } else if (isset($message["message"])) { ?>
            <!-- <p style="color:red;"><?php echo $message["message"]; ?></p> -->
    <?php } ?>


    <!-- JavaScript to Show Update Form and Pre-fill Data -->
    <script>
        function showUpdateForm(id, username, password, firstName, lastName, isAdmin) {
            // Set form values
            document.getElementById('updateId').value = id;
            document.getElementById('updateUsername').value = username;
            document.getElementById('updatePassword').value = password;
            document.getElementById('updateFirstName').value = firstName;
            document.getElementById('updateLastName').value = lastName;
            document.getElementById('updateIsAdmin').value = isAdmin;

            
            document.getElementById('updateForm').style.display = 'block';
        }
    </script>

</body>

</html>