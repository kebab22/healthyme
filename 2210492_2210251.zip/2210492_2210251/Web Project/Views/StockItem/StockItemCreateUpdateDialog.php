<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <title>Create | Edit</title>

    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/5.15.3/css/all.min.css">
    <link rel="stylesheet" href="../../Assets/CSS/dialog.css">
    <link rel="stylesheet" type="text/css" href="../../Assets/CSS/stylelog.css">
    <link rel="icon" href="../../Assets/Images/final-logo.jfif">

    <style>
        body {
            font-family: Arial, sans-serif;
            margin: 20px;
        }

        h1 {
            color: #333;
            text-align: center;
        }

        form {
            width: 300px;
            margin: 0 auto;
        }

        label {
            font-weight: bold;
            color: #555;
            display: block;
            margin-bottom: 5px;
        }

        input[type="text"],
        input[type="number"],
        input[type="submit"],
        select {
            width: 100%;
            padding: 8px;
            margin-bottom: 10px;
            border: 1px solid #ccc;
            border-radius: 4px;
            box-sizing: border-box;
        }

        select {
            appearance: none;
            -webkit-appearance: none;
            -moz-appearance: none;
            background-image: url('data:image/svg+xml;utf8,<svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 24 24" fill="%23333"><path d="M7 10l5 5 5-5H7z"/></svg>');
            background-repeat: no-repeat;
            background-position-x: calc(100% - 10px);
            background-position-y: center;
            padding-right: 30px;
            cursor: pointer;
        }

        input[type="submit"] {
            background-color: #4CAF50;
            color: white;
            padding: 10px 20px;
            border: none;
            border-radius: 4px;
            cursor: pointer;
            font-size: 16px;
        }

        input[type="submit"]:hover {
            background-color: #45a049;
        }

        #clothesFields,
        #equipmentFields {
            display: block;
        }

    </style>

</head>

<body>
    <center>
        <h1>Create For Stock Item</h1>
    </center>
    <br />
    <br />
    <br />
    <br />

    <form name="login" id="login" action="../StockItem/createStock.php" method="post">
        <center>

            <label for="productType">Product Type:</label>
            <select name="productType" id="productType" onchange="toggleFields()">

                <option value="clothes">Clothes</option>
                <option value="equipment">Equipment</option>

            </select>
            <br><br>

            <label for="productname">Product Name: </label>
            <input type="text" id="productname" name="productname"
                placeholder="Sweater/Dumbell/Band/Mat/Tshirt/Short"><br /><br />

            <label for="inStock">Item Stock: </label>
            <input type="number" id="inStock" name="inStock" placeholder="Enter a Number" /><br /><br />

            <!-- for clothes -->
            <div id="clothesFields">
                <label for="clothesColor">Color:</label>
                <input type="text" name="clothesColor" id="clothesColor">
                <br>
                <label for="clothesPrice">Price:</label>
                <input type="text" name="clothesPrice" id="clothesPrice">
                <br>
                <label for="size">Size:</label>
                <input type="text" name="size" id="size">
                <br>
            </div>

            <!-- For equipment -->
            <div id="equipmentFields" style = "display:none;">
                <label for="equipmentColor">Color:</label>
                <input type="text" name="equipmentColor" id="equipmentColor">
                <br>
                <label for="equipmentPrice">Price:</label>
                <input type="text" name="equipmentPrice" id="equipmentPrice">
                <br>
            </div>

        </center>

        <br>

        <center><input type="submit" class="mubutton" value="Create"></center>
    </form>

    <script>
        function toggleFields() {
            var productType = document.getElementById("productType").value;
            var clothesFields = document.getElementById("clothesFields");
            var equipmentFields = document.getElementById("equipmentFields");

            if (productType === "clothes") {
                clothesFields.style.display = "block";
                equipmentFields.style.display = "none";
            } else if (productType === "equipment") {
                clothesFields.style.display = "none";
                equipmentFields.style.display = "block";
            }
        }
    </script>


</body>

</html>