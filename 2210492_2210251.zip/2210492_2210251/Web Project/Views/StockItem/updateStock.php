<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Update XML Data</title>
    <style>
        body {
            font-family: Arial, sans-serif;
            margin: 20px;
        }

        h2 {
            color: #333;
        }

        form {
            width: 300px;
            margin: 0 auto;
        }

        label {
            font-weight: bold;
            color: #555;
            display: block;
            margin-bottom: 5px;
        }

        input[type="text"],
        input[type="number"],
        input[type="submit"] {
            width: 100%;
            padding: 8px;
            margin-bottom: 10px;
            border: 1px solid #ccc;
            border-radius: 4px;
            box-sizing: border-box;
        }

        input[type="submit"] {
            background-color: #4CAF50;
            color: white;
            padding: 10px 20px;
            border: none;
            border-radius: 4px;
            cursor: pointer;
            font-size: 16px;
        }

        input[type="submit"]:hover {
            background-color: #45a049;
        }
    </style>
</head>

<body>
    <h2>Update Data</h2>
    <?php
    function loadData($itemId) {
        global $productName, $inStock, $color, $price, $size;

     
        $xml = new DOMDocument();
        $xml->load('crud.xml');

        // Find the item in the XML file
        $stocks = $xml->getElementsByTagName('stock');
        foreach ($stocks as $stock) {
            $itemIdValue = $stock->getElementsByTagName('itemId')->item(0)->nodeValue;
            if ($itemIdValue && $itemIdValue == $itemId) {
                $productName = $stock->getElementsByTagName('productname')->item(0)->nodeValue;
                $inStock = $stock->getElementsByTagName('inStock')->item(0)->nodeValue;

                // Load clothes or equipment data based on the product type
                $clothes = $stock->getElementsByTagName('clothes')->item(0);
                $equipment = $stock->getElementsByTagName('equipment')->item(0);

                if ($clothes) {
                    $color = $clothes->getElementsByTagName('color')->item(0)->nodeValue;
                    $price = $clothes->getElementsByTagName('price')->item(0)->nodeValue;
                    $size = $clothes->getElementsByTagName('size')->item(0)->nodeValue;
                    break; 

                } elseif ($equipment) {
                    $color = $equipment->getElementsByTagName('color')->item(0)->nodeValue;
                    $price = $equipment->getElementsByTagName('price')->item(0)->nodeValue;
                    break; 
                }
            }
        }
    }

    $itemId = $_GET["itemId"];
    loadData($itemId);
    ?>

<form method="post" action='updateStock2.php?itemId=<?php echo $itemId; ?>'>

<label for="productname">Product Name: </label>
<input type="text" id="productname" value="<?php echo $productName ?>" name="productname" placeholder="Sweater/Dumbell/Band/Mat/Tshirt/Short"><br /><br />

<label for="inStock">Item Stock: </label>
<input type="number" id="inStock" value="<?php echo $inStock ?>" name="inStock" placeholder="Enter a Number" /><br /><br />

<?php if (isset($size)) : ?>
    <!-- For clothes -->
    <div id="clothesFields">
        <label for="clothesColor">Color:</label>
        <input type="text" value="<?php echo $color ?>" name="clothesColor" id="clothesColor">
        <br>
        <label for="clothesPrice">Price:</label>
        <input type="text" value="<?php echo $price ?>" name="clothesPrice" id="clothesPrice">
        <br>
        <label for="size">Size:</label>
        <input type="text" value="<?php echo $size ?>" name="size" id="size">
        <br>
    </div>
<?php else : ?>
    <!-- For equipment -->
    <div id="equipmentFields">
        <label for="equipmentColor">Color:</label>
        <input type="text" value="<?php echo $color ?>" name="equipmentColor" id="equipmentColor">
        <br>
        <label for="equipmentPrice">Price:</label>
        <input type="text" value="<?php echo $price ?>" name="equipmentPrice" id="equipmentPrice">
        <br>
    </div>
<?php endif; ?>

<input type="submit" class="mubutton" value="Update"></center>
</form>


</body>

</html>