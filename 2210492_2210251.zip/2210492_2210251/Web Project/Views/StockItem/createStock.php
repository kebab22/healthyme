<?php
   
    $xmlFile = "crud.xml";
    $xml = simplexml_load_file($xmlFile);

    $maxItemId = 0;
    foreach($xml -> stock as $stock){
        $itemId = (int)$stock -> itemId;
            if ($itemId > $maxItemId) {
                $maxItemId = $itemId;
            }
    }

  
    $newItemId = $maxItemId + 1;

    // Determine the type of product
    $productType = $_POST['productType'];

    // Create a new <stock> element
    $newStock = $xml->addChild('stock');

    // Adding child elements 
    $newStock->addChild('itemId',  $newItemId);
    $newStock->addChild('productname', $_POST['productname']);
    $newStock->addChild('inStock', $_POST['inStock']);

        // Add data specific to clothes or equipment
        if ($productType == 'clothes') {
            $clothes = $newStock->addChild('clothes');
            $clothes->addChild('color', $_POST['clothesColor']); 
            $clothes->addChild('price', $_POST['clothesPrice']); 
            $clothes->addChild('size', $_POST['size']);
            
        } elseif ($productType == 'equipment') {
            $equipment = $newStock->addChild('equipment');
            $equipment->addChild('color', $_POST['equipmentColor']); 
            $equipment->addChild('price', $_POST['equipmentPrice']);
        }

    
    $xml->asXML($xmlFile);

  
    header("Location: StockItemCrud.php");
    exit;
?>