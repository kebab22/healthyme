<?php
    $xmlFile = "crud.xml";
    $xml = simplexml_load_file($xmlFile);
    if ($xml === false) {
        echo ""; // Return empty string if XML file loading fails
    } else {
        // Find the maximum itemId
        $maxItemId = 0;
        foreach ($xml->stock as $stock) {
            $itemId = (int)$stock->itemId;
            if ($itemId > $maxItemId) {
                $maxItemId = $itemId;
            }
        }
        // Increment the maximum itemId to get the next available itemId
        $nextItemId = $maxItemId + 1;
        echo $nextItemId;
    }
?>
