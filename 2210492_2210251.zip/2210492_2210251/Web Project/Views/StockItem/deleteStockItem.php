<?php

$xmlFile = "crud.xml";
$doc = new DOMDocument();
$doc->load($xmlFile);

$itemId = isset($_GET['itemId']) ? $_GET['itemId'] : null;

if ($itemId === null) {
    die("No itemId provided for deletion.");
}

// Find the element with matching itemId
$xpath = new DOMXPath($doc);
$elements = $xpath->query("//stock[itemId='$itemId']");

if ($elements->length === 0) {
    die("Item with itemId '$itemId' not found.");
}

// Remove the matching element
foreach ($elements as $element) {
    $element->parentNode->removeChild($element);
}


$doc->save($xmlFile);


header('location: StockItemCrud.php');
exit;
?>
