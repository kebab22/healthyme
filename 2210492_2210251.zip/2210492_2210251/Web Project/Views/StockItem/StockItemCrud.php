<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <title>Stock Item Management</title>

    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/5.15.3/css/all.min.css">
    <link rel="stylesheet" href="../../Assets/CSS/dialog.css">
    <link rel="icon" href="../../Assets/Images/final-logo.jfif">
    <style>
        body {
            font-family: Arial, sans-serif;
            margin: 0;
            padding: 0;
            background-color: #f8f8f8; 
        }

        button {
            background-color: #007bff;
            color: white;
            border: none;
            padding: 10px 20px;
            margin: 10px;
            border-radius: 5px;
            cursor: pointer;
        }

        button:hover {
            background-color: #0056b3; 
        }

        table {
            width: 100%;
            border-collapse: collapse;
            margin-top: 20px;
        }

        th, td {
            border: 1px solid #dddddd;
            padding: 8px;
            text-align: left;
        }

        th {
            background-color: #f2f2f2; 
        }

        tr:nth-child(even) {
            background-color: #ffffff; 
        }

        tr:nth-child(odd) {
            background-color: #f8f8f8; 
        }

        form {
            display: inline-block; 
        }

        form button {
            background-color: #dc3545; 
            color: white;
            border: none;
            padding: 5px 10px;
            border-radius: 3px;
            cursor: pointer;
        }

        form button:hover {
            background-color: #c82333; 
        }
    </style>
</head>

<body>
    <a href="StockItemCreateUpdateDialog.php">
        <button><i class="fas fa-plus-circle"></i> Create</button></a>

    <?php

    // include('../../Shared/connect_db.php');
    // header("Content-type: text/xml");
    $xmlFile = "crud.xml";
    $xml = simplexml_load_file($xmlFile) or die("Error: Cannot create object");
    $table = "<table><tr><th>ItemId</th><th>Productname</th><th>inStock</th><th>Color</th><th>Price</th><th>size</th><th>Action</th></tr>";
    foreach ($xml->stock as $stocks) {
        $itemId = $stocks->itemId;
        $productname = $stocks->productname;
        $inStock = $stocks->inStock;
       

        //  Check if <clothes> element exists for the current <stock> element
        if (isset($stocks->clothes)) {

            // If <clothes> exists, access its <size> property
            $size = $stocks->clothes->size;
            $color = $stocks->clothes->color;
            $price = $stocks->clothes->price;
        } else {
            // If <clothes> does not exist, set $size to an empty string
            $color = $stocks->equipment->color;
            $price = $stocks->equipment->price;
            $size = "";
        }

        // Construct table row with the retrieved values
        $table .= "<tr><td>$itemId</td><td>$productname</td><td>$inStock</td><td>$color</td><td>$price</td><td>$size</td><td>
        <form method='get' action='deleteStockItem.php?itemId=<?php echo $itemId; ?>'>
            <input type='hidden' name='itemId' value='$itemId'>
            <button type='submit' onclick='return confirmDelete();'><i class='fas fa-trash-alt'></i></button>
        </form>
        <form method='get' action='updateStock.php'>
        <input type='hidden' name='itemId' value='$itemId'>
        <button type='submit'><i class='fas fa-edit'></i></button>
    </form></td></tr>";
    }

    
    $table .= "</table>";

    
    echo $table;

?>

    <script>
        function confirmDelete() {
            return confirm("Are you sure you want to delete this item?");
        }
    </script>

</body>

</html>