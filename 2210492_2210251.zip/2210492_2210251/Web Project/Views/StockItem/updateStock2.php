<?php
// Check if form is submitted
if ($_SERVER["REQUEST_METHOD"] == "POST") {
    // Get the item ID from the query string
    $itemId = isset($_GET["itemId"]) ? $_GET["itemId"] : null;

    if ($itemId !== null) {
        // Retrieve form data
        $productName = isset($_POST["productname"]) ? $_POST["productname"] : '';
        $inStock = isset($_POST["inStock"]) ? $_POST["inStock"] : '';
        $clothesColor = isset($_POST["clothesColor"]) ? $_POST["clothesColor"] : '';
        $clothesPrice = isset($_POST["clothesPrice"]) ? $_POST["clothesPrice"] : '';
        $size = isset($_POST["size"]) ? $_POST["size"] : '';
        $equipmentColor = isset($_POST["equipmentColor"]) ? $_POST["equipmentColor"] : '';
        $equipmentPrice = isset($_POST["equipmentPrice"]) ? $_POST["equipmentPrice"] : '';

        // Load the XML file
        $xml = new DOMDocument();
        $xml->load('crud.xml');

        // Find the item in the XML file
        $stocks = $xml->getElementsByTagName('stock');
        foreach ($stocks as $stock) {
            $itemIdNode = $stock->getElementsByTagName('itemId')->item(0);
            if ($itemIdNode && $itemIdNode->nodeValue == $itemId) {
                // Update the item details
                $stock->getElementsByTagName('productname')->item(0)->nodeValue = $productName;
                $stock->getElementsByTagName('inStock')->item(0)->nodeValue = $inStock;

                // Update clothes details if applicable
                $clothes = $stock->getElementsByTagName('clothes')->item(0);
                if ($clothes) {
                    if (!empty($clothesColor)) {
                        $clothes->getElementsByTagName('color')->item(0)->nodeValue = $clothesColor;
                    }
                    if (!empty($clothesPrice)) {
                        $clothes->getElementsByTagName('price')->item(0)->nodeValue = $clothesPrice;
                    }
                    if (!empty($size)) {
                        $clothes->getElementsByTagName('size')->item(0)->nodeValue = $size;
                    }
                }

                // Update equipment details if applicable
                $equipment = $stock->getElementsByTagName('equipment')->item(0);
                if ($equipment) {
                    if (!empty($equipmentColor)) {
                        $equipment->getElementsByTagName('color')->item(0)->nodeValue = $equipmentColor;
                    }
                    if (!empty($equipmentPrice)) {
                        $equipment->getElementsByTagName('price')->item(0)->nodeValue = $equipmentPrice;
                    }
                }
            }
        }

       
        $xml->save('crud.xml');

        
        header("Location: StockItemCrud.php");
        exit();
    } else {
       
        echo "Error: Item ID not provided.";
    }
} else {
   
    echo "Error: Form not submitted.";
}
?>
