<!DOCTYPE html>
<html lang="en">
    <head>
        <title>My Admin</title>
            <link rel="stylesheet" href="Assets/CSS/stylelog.css">
            <link rel="icon" href="Assets\Images\final-logo.jfif">
    </head>
    <style>
		/* .loginImage {
			width: 100%;
			position: absolute;
			background-size: cover;
			display: block;
			height: auto;
		} */

		body {
			background-image: url("/Web Project/Assets/Images/photoForLogin.jpg");
			/* margin: 0;
			padding: 0;
			width: 100%;
			height: auto;
			font-family: 'Arial';
			position: absolute;
			top: 0;
			left: 0;
			right: 0;
			width: auto;
			background-size: 100%; */
		}

		.form {
			width: 382px;
			overflow: hidden;
			margin: auto;
			margin: 20 0 0 450px;
			padding: 50px;
			background: #C0C0C0;
			border-radius: 15px;
			position: absolute;
			top: 200px;
			left: 30%;

		}
	</style>
    <body>
        <div class="border">
                <nav class="nav">
                        <img class="logo" src="../Web Project/Assets/Images/final-logo.jfif">
                <ul>
                                <li><a class="active">Admin Page</a></li>
                                <li><a class="active" href="index.html">Home</a></li>
                                <li><a href="Views\User\LoginPage.html" class="active2">Login</a></li>
                            </ul>
                </nav>
        </div>
                    
            <div class="form">
                    
            <center>        
                    <form name="login" id="login" action="../Web Project/Views/Admin/validate_admin.php" method="post">
                    
                        <label class="input_label"></label>
                        <input type="text" id="txt" name="uname_txt" placeholder="Username"><br/><br/>
                        
                        <input type="password" id="txt_name" name="pass_txt" placeholder="Password"/>
                        </p>


                        <input type="submit" class="mybutton" value="LOG IN"/><button onclick=" href='admin_details';"></button></p>
            </center>

                    </form>
            </div>

            
    </body>
</html>