<?php
if ($_SERVER['REQUEST_METHOD'] == 'POST') {
    // Collect user input with validation
    $intake = filter_var($_POST['intake'], FILTER_VALIDATE_INT);
    $age = filter_var($_POST['age'], FILTER_VALIDATE_INT);
    $gender = $_POST['gender'];
    $activity_level = $_POST['activity_level'];

    // Validate inputs
    if ($intake === false || $intake < 0 || $age < 0) {
        echo "<p class='error'>Please enter valid positive integers for caloric intake and age.</p>";
        return;
    }

    // Calculate average caloric requirement based on age and gender
    function calculateCaloricRequirement($age, $gender)
    {
        if ($gender == 'male') {
            if ($age >= 18 && $age <= 30) return 2700;
            if ($age >= 31 && $age <= 50) return 2500;
            if ($age > 50) return 2300;
        } elseif ($gender == 'female') {
            if ($age >= 18 && $age <= 30) return 2100;
            if ($age >= 31 && $age <= 50) return 2000;
            if ($age > 50) return 1900;
        }
        return 2000; // Default average
    }

    // Get average caloric requirement
    $averageCaloricRequirement = calculateCaloricRequirement($age, $gender);

    // URL of the WSDL
    $wsdl = "http://www.dneonline.com/calculator.asmx?WSDL";

    try {
        // Create a new SoapClient instance
        $client = new SoapClient($wsdl);
        $params = ['intA' => $intake, 'intB' => $averageCaloricRequirement];
        $result = $client->Subtract($params)->SubtractResult;

        // Analyze the result
        $feedback = "";
        $advice = "";

          if ($result > 0) {
            $feedback = "<h2>Caloric Surplus</h2><p>You are consuming " . $result . " more calories than your average requirement.</p>";
            $advice = "<p><strong>Advice:</strong> Consider reducing your caloric intake. You might want to:</p>
                       <ul>
                           <li>Focus on whole foods like fruits, vegetables, and lean proteins.</li>
                           <li>Reduce high-calorie snacks and sugary drinks.</li>
                           <li>Increase your physical activity to help balance your caloric intake.</li>
                       </ul>";
        } elseif ($result < 0) {
            $feedback = "<h2>Caloric Deficit</h2><p>You are consuming " . abs($result) . " fewer calories than your average requirement.</p>";
            $advice = "<p><strong>Advice:</strong> Consider increasing your caloric intake. You might want to:</p>
                       <ul>
                           <li>Include more healthy fats such as avocados, nuts, and olive oil in your meals.</li>
                           <li>Snack on calorie-dense foods like nut butter or granola bars.</li>
                           <li>Increase portion sizes of your meals or add extra meals throughout the day.</li>
                       </ul>";
        } else {
            $feedback = "<h2>Caloric Balance</h2><p>You are consuming the exact number of calories as your average requirement.</p>
                         <p>Your weight is likely to remain stable.</p>";
        }

         // Display results
         echo "<div class='feedback'>$feedback</div>";
         if ($advice) {
             echo "<div class='advice'>$advice</div>";
         }
         
         echo "<script>
             var caloricIntake = $intake;
             var averageCaloricRequirement = $averageCaloricRequirement;
             var difference = $result;
         </script>";
     } catch (SoapFault $e) {
         echo "<p class='error'>Error: " . $e->getMessage() . "</p>";
     }
 }
 ?>

<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link rel="icon" href="../../Assets/Images/final-logo.jfif">
    <title>Caloric Tracker</title>
    <script src="https://cdn.jsdelivr.net/npm/chart.js"></script>
    <style>
        body {
            font-family: Arial, sans-serif;
            background-color: #f4f4f4;
            margin: 0;
            padding: 0;
        }

        .container {
            max-width: 800px;
            margin: 50px auto;
            background-color: white;
            padding: 20px;
            border-radius: 8px;
            box-shadow: 0 0 10px rgba(0, 0, 0, 0.1);
        }

        h1, h2 {
            color: #333;
        }

        .form-group {
            margin-bottom: 15px;
        }

        .form-group label {
            display: block;
            margin-bottom: 5px;
            font-weight: bold;
        }

        .form-group input,
        .form-group select {
            width: 100%;
            padding: 10px;
            font-size: 16px;
            border-radius: 4px;
            border: 1px solid #ccc;
            box-sizing: border-box;
        }

        .form-group input[type="submit"] {
            background-color: #28a745;
            color: white;
            border: none;
            cursor: pointer;
            transition: background-color 0.3s ease;
        }

        .form-group input[type="submit"]:hover {
            background-color: #218838;
        }

        .feedback {
            margin-top: 20px;
            padding: 15px;
            background-color: #eabb99;
            border-left: 5px solid #d16619;
            color: #0c5460;
            border-radius: 4px;
        }

        .advice {
            margin-top: 20px;
            padding: 15px;
            background-color: #faefe8;
            border-left: 5px solid #cc8f64; 
            color: #0f5132; 
            border-radius: 4px;
        }

        .error {
            color: red;
        }

        canvas {
            margin-top: 20px;
            max-width: 100%; /* Ensure responsiveness */
        }
    </style>
</head>

<body>
    <div class="container">
        <!-- Canvas for Chart.js -->
        <canvas id="caloricChart" width="400" height="200"></canvas>
        <div id="summary"></div>
    </div>

    <script>
    function updateChart() {
        const ctx = document.getElementById('caloricChart').getContext('2d');
        const caloricChart = new Chart(ctx, {
            type: 'bar',
            data: {
                labels: ['Caloric Intake', 'Average Requirement', 'Difference (Surplus/Deficit)'],
                datasets: [
                    {
                        label: 'Calories',
                        data: [caloricIntake, averageCaloricRequirement, difference],
                        backgroundColor: [
                            'rgba(75, 192, 192, 0.2)',
                            'rgba(255, 99, 132, 0.2)',
                            'rgba(54, 162, 235, 0.2)'
                        ],
                        borderColor: [
                            'rgba(75, 192, 192, 1)',
                            'rgba(255, 99, 132, 1)',
                            'rgba(54, 162, 235, 1)'
                        ],
                        borderWidth: 1,
                        type: 'bar'
                    },
                    {
                        label: 'Difference Trend',
                        data: [null, null, difference],
                        borderColor: 'rgba(153, 102, 255, 1)',
                        backgroundColor: 'rgba(153, 102, 255, 0.2)',
                        fill: false,
                        tension: 0.4,
                        type: 'line'
                    }
                ]
            },
            options: {
                responsive: true,
                plugins: {
                    title: {
                        display: true,
                        text: 'Caloric Intake vs Requirement',
                        font: {
                            size: 18
                        }
                    },
                    tooltip: {
                        callbacks: {
                            label: function (tooltipItem) {
                                const label = tooltipItem.dataset.label || '';
                                const value = tooltipItem.raw;
                                if (tooltipItem.datasetIndex === 0) {
                                    return `${label}: ${value} cal`;
                                } else if (tooltipItem.datasetIndex === 1) {
                                    return `${label}: ${value} cal`;
                                }
                            }
                        }
                    }
                },
                scales: {
                    y: {
                        beginAtZero: true,
                        title: {
                            display: true,
                            text: 'Calories'
                        },
                        ticks: {
                            stepSize: 500
                        }
                    }
                },
                animation: {
                    duration: 1000,
                    easing: 'easeInOutBounce'
                }
            }
        });
    }

    if (typeof caloricIntake !== 'undefined' && typeof averageCaloricRequirement !== 'undefined') {
        updateChart();
    }
    </script>
</body>
</html>
