---------------------------------------------
-- File: CreateDB_HealthyMe.sql
-- Created by: Haifa Maudarbocus and blablabla
---------------------------------------------

-- Table UserAccount --

CREATE TABLE `user_account` (
    `user_id` varchar(25) NOT NULL,
    `username` varchar(25) NOT NULL,
    `password` varchar(25) NOT NULL,
    `first_name` varchar(25) NOT NULL,
    `last_name` varchar(25) NOT NULL,
    `is_admin`  BOOLEAN NOT NULL,
    PRIMARY KEY (user_id)
)

-- Table xxx --