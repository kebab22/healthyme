
----------------------------------------------------------
-- Database: `healthyme`
--
-- Created by Haïfa Maudarbocus(2210492) & Jahnavi Sewnundun(2910251)
--
-- Web Assignment DGT1032Y Year 1 Semester 2 
--
-- Lecturer : DR Zahra Mungloo Dilmohamud 
--
-- Database: `healthyme`
--
CREATE DATABASE IF NOT EXISTS `healthyme`;
USE `healthyme`;

-- --------------------------------------------------------

--
-- Table structure for table `depends_on`
--

CREATE TABLE `depends_on` (
  `item_id` varchar(25) NOT NULL,
  `order_id` varchar(25) NOT NULL
);

-- --------------------------------------------------------

--
-- Table structure for table `order_item`
--

CREATE TABLE `order_item` (
  `order_id` int(11) NOT NULL,
  `product_name` varchar(10) NOT NULL,
  `quantity` smallint(6) NOT NULL,
  `total_price` smallint(6) NOT NULL,
  `order_date` date NOT NULL
);

-- --------------------------------------------------------

--
-- Table structure for table `stock_item`
--

CREATE TABLE `stock_item` (
  `item_id` int(11) NOT NULL,
  `product_name` varchar(10) NOT NULL,
  `in_stock` smallint(6) NOT NULL,
  `size` varchar(5) NOT NULL,
  `color` varchar(10) NOT NULL,
  `price` smallint(6) NOT NULL
);

--
-- Dumping data for table `stock_item`
--

INSERT INTO `stock_item` (`item_id`, `product_name`, `in_stock`, `size`, `color`, `price`) VALUES
(1, 'Product A', 50, 'S', 'Red', 560),
(2, 'Product B', 60, 'M', 'Blue', 800),
(3, 'Tshirt', 10, 'S', 'Black', 300),
(4, 'Tshirt', 10, 'S', 'Black', 300),
(5, 'Sweater', 5, 'S', 'Red', 500),
(6, 'Tshirt', 20, 'M', 'White', 600);

-- --------------------------------------------------------

--
-- Table structure for table `user_account`
--

CREATE TABLE `user_account` (
  `user_id` int(25) NOT NULL,
  `username` varchar(25) NOT NULL,
  `password` varchar(25) NOT NULL,
  `first_name` varchar(25) NOT NULL,
  `last_name` varchar(25) NOT NULL,
  `is_admin` tinyint(1) NOT NULL
);

--
-- Dumping data for table `user_account`
--

INSERT INTO `user_account` (`user_id`, `username`, `password`, `first_name`, `last_name`, `is_admin`) VALUES
(2, 'haifa', '1234', 'haifa', 'maudarbocus', 1),
(3, 'haifa', '1234', 'haifa', 'maudarbocus', 1),
(4, 'test', '1234', 'haifa', 'maudarbocus', 1),
(5, 'test2', '1234', '1234', '1234', 1),
(6, 'kebab', '6549', 'kebab', 'test', 0),
(7, 'haifa', '1234', 'haifa', 'maudarbocus', 1),
(8, 'john', '65432', 'john', 'smith', 0);

--
-- Indexes for dumped tables
--

--
-- Indexes for table `depends_on`
--
ALTER TABLE `depends_on`
  ADD PRIMARY KEY (`item_id`,`order_id`),
  ADD KEY `order_id` (`order_id`);

--
-- Indexes for table `order_item`
--
ALTER TABLE `order_item`
  ADD PRIMARY KEY (`order_id`);

--
-- Indexes for table `stock_item`
--
ALTER TABLE `stock_item`
  ADD PRIMARY KEY (`item_id`);

--
-- Indexes for table `user_account`
--
ALTER TABLE `user_account`
  ADD UNIQUE KEY `user_id` (`user_id`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `order_item`
--
ALTER TABLE `order_item`
  MODIFY `order_id` int(11) NOT NULL AUTO_INCREMENT;
--
-- AUTO_INCREMENT for table `stock_item`
--
ALTER TABLE `stock_item`
  MODIFY `item_id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=7;
--
-- AUTO_INCREMENT for table `user_account`
--
ALTER TABLE `user_account`
  MODIFY `user_id` int(25) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=9;COMMIT;
